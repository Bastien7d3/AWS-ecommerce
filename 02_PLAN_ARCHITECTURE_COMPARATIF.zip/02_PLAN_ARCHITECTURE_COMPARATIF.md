# Plan du Projet AWS — E-Commerce Haute Disponibilité & Batch Spot (FISA 2026)

**Étudiant :** Bastien | **Compte AWS :** `689505268069` | **Région :** `eu-west-3` (Paris)  
**Enseignant :** Pr. Raouf Boulkroune | **Outil IaC :** Terraform `v1.16.6`

---

## 1. Les 2 Solutions Théoriques Comparées (Attendu du Sujet)

```mermaid
flowchart TD
    subgraph S1["SOLUTION 1 : Approche 100 % Machines Virtuelles (IaaS)"]
        direction TB
        ALB1["Application Load Balancer (Multi-AZ)"]
        EC2_1["EC2 Web/App Zone A (t3.micro)"]
        EC2_2["EC2 Web/App Zone B (t3.micro)"]
        RDS["Base de données Amazon RDS (Multi-AZ)"]
        MSK["Amazon MSK (Cluster Kafka managé)"]
        Worker1["EC2 Worker Traitement & Expédition"]
        
        ALB1 --> EC2_1 & EC2_2
        EC2_1 & EC2_2 --> RDS
        EC2_1 & EC2_2 --> MSK --> Worker1
    end

    subgraph S2["SOLUTION 2 : Approche 100 % Serverless (Cloud-Native)"]
        direction TB
        CF["Amazon CloudFront (CDN mondial)"]
        S3["Bucket S3 (Hébergement site web)"]
        APIGW["Amazon API Gateway"]
        L_Order["AWS Lambda (Création commande)"]
        L_Fulfill["AWS Lambda (Traitement / Expédition)"]
        DDB["Amazon DynamoDB (NoSQL Serverless)"]
        SNS2["Amazon SNS (Topic)"]
        SQS2["Amazon SQS (File d'attente)"]
        
        CF --> S3
        CF --> APIGW --> L_Order
        L_Order --> DDB
        L_Order --> SNS2 --> SQS2 --> L_Fulfill
    end
```

---

## 2. L'Architecture Hybride Déployée en Terraform (Optimisée Free Tier & FinOps)

Pour répondre **à 100 % des exigences du sujet** (EC2 + Serverless + Haute Disponibilité + Événementiel SNS + Surveillance CloudWatch + Maîtrise des coûts), voici l'architecture complète que nous implémentons :

```mermaid
flowchart TB
    Client["Client (Navigateur Web & Boîte Mail)"]
    Admin["Admin Cloud (Réglage seuils Terraform / CloudWatch)"]

    subgraph IaaS_HA["1. Front-End Haute Disponibilité (IaaS Multi-AZ)"]
        ALB["Application Load Balancer (Public)"]
        EC2_A["VM EC2 Web Zone A (t3.micro)"]
        EC2_B["VM EC2 Web Zone B (t3.micro)"]
        ALB --> EC2_A & EC2_B
    end

    subgraph Serverless_Core["2. Prise de Commande Synchrone (Serverless)"]
        Lambda["AWS Lambda: CreateOrder"]
        DDB[("Amazon DynamoDB: Catalogue & Commandes")]
    end

    subgraph Event_Monitoring["3. File Tampon, Notifications SNS & Surveillance CloudWatch"]
        SNS_Order(("SNS: Confirmation Commande"))
        SNS_Ship(("SNS: Notification Expédition + N° Suivi"))
        SQS[["Amazon SQS: orders-batch-queue"]]
        CW_Alarm["CloudWatch Alarm: Surveillance Nombre de Commandes"]
    end

    subgraph Spot_Batch["4. Traitement Lourd Asynchrone (EC2 Spot Élastique : 0 -> 1 -> 2 VM)"]
        Spot1["EC2 Spot Worker #1 (Batch normal / Nuit)"]
        Spot2["EC2 Spot Worker #2 (Renfort si pic de commandes !)"]
        S3_PDF[("Amazon S3: Factures PDF & Rapports Audit")]
    end

    Client -->|1. Parcourt le catalogue & commande| ALB
    EC2_A & EC2_B -->|2. Appelle| Lambda
    Lambda -->|3. Enregistre (Statut: PENDING)| DDB
    Lambda -->|4a. Déclenche confirmation immédiate| SNS_Order
    SNS_Order -.->|Mail 1 : Commande reçue| Client
    Lambda -->|4b. Empile la commande| SQS

    Admin -.->|Configure seuil (ex: > 10 ou > 50 cmd)| CW_Alarm
    SQS -->|Métrique: ApproximateNumberOfMessagesVisible| CW_Alarm
    CW_Alarm -->|Seuil 1 atteint -> Lance 1 Spot<br>Seuil 2 (Pic) -> Split le batch sur 2 Spot !| Spot1 & Spot2

    SQS -->|5. Dépile en parallèle| Spot1 & Spot2
    Spot1 & Spot2 -->|6a. Calcule taille colis (S/M/L/XL) + N° Suivi| DDB
    Spot1 & Spot2 -->|6b. Génère Facture PDF + Étiquette| S3_PDF
    Spot1 & Spot2 -->|6c. Statut = SHIPPED + N° Suivi + Lien PDF| SNS_Ship
    SNS_Ship -.->|Mail 2 : Colis Expédié + N° de Suivi !| Client
```

---

## 3. Fonctionnement Détaillé du Batch EC2 Spot & de la Surveillance CloudWatch

### 3.1 Les 3 tâches exécutées par le Worker EC2 Spot
1. **Calcul de dimensionnement du colis (*Carrier Box Sizing*)** :
   * Chaque produit du catalogue possède des dimensions $(L \times l \times h\text{ en cm})$ et un poids $(\text{kg})$.
   * Le worker calcule le volume total et le poids total de la commande, puis sélectionne automatiquement le carton transporteur prédéfini optimal :
     * **Colis S (Petit)** : $20 \times 15 \times 10\text{ cm}$ ($\le 2\text{ kg}$) — Tarif transporteur : 4,90 €
     * **Colis M (Standard)** : $40 \times 30 \times 20\text{ cm}$ ($\le 10\text{ kg}$) — Tarif transporteur : 8,90 €
     * **Colis L (Volumineux)** : $60 \times 40 \times 40\text{ cm}$ ($\le 25\text{ kg}$) — Tarif transporteur : 14,90 €
     * **Colis XL (Hors-gabarit / Palette)** : $100 \times 60 \times 60\text{ cm}$ ($> 25\text{ kg}$) — Tarif transporteur : 29,90 €
2. **Génération de la Facture PDF Officielle & Archivage S3** :
   * Le worker compile un fichier PDF contenant le détail HT/TVA/TTC, le récapitulatif logistique (format de carton retenu, poids total, taux de remplissage du carton) et le **numéro de suivi transporteur** (`TRK-FR-...`).
   * Le PDF est stocké dans un bucket **Amazon S3** dédié à l'audit et à la facturation.
3. **Mise à jour de l'état de la commande & Notification SNS d'expédition** :
   * La commande passe successivement de `PENDING` $\rightarrow$ `PACKAGED` $\rightarrow$ `SHIPPED` dans DynamoDB (avec son numéro de suivi, la taille du carton et le lien vers le PDF).
   * Le worker publie un événement dans **Amazon SNS** qui envoie un e-mail au client contenant **son numéro de suivi transporteur** et le lien de téléchargement de sa facture PDF !

### 3.2 Surveillance CloudWatch & Dédoublement du Batch ("Split en 2")
C'est très simple à implémenter dans Terraform grâce au couplage natif **SQS + CloudWatch Alarm + Auto Scaling Spot** :
* La métrique AWS native `ApproximateNumberOfMessagesVisible` compte en temps réel le nombre de commandes en attente dans la file SQS.
* L'administrateur Cloud dispose de **2 variables Terraform** très simples à régler :
  * `batch_trigger_threshold` (ex : `10` commandes) : Dès que la file atteint ce seuil, une alarme CloudWatch déclenche automatiquement le lancement d'**1 instance EC2 Spot** sans attendre la nuit.
  * `batch_split_threshold` (ex : `50` commandes) : S'il y a un pic anormal de commandes, une seconde alarme CloudWatch lance une **2ème instance EC2 Spot en parallèle** !
* **Comment le batch est-il "splitté" en 2 sans doublon ?**
  * C'est la magie d'**Amazon SQS** : grâce au mécanisme de *Visibility Timeout*, dès que le Worker Spot #1 prend un lot de 10 commandes, ces 10 commandes deviennent invisibles pour le Worker Spot #2, qui prend immédiatement les 10 suivantes ! Le temps de traitement est ainsi divisé par 2 sans aucune ligne de code complexe de synchronisation.
  * Dès que la file SQS retombe à `0`, les instances Spot s'arrêtent automatiquement (*Scale-to-Zero*).
